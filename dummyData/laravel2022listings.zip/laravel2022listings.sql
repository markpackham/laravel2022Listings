-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2022 at 05:11 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel2022listings`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

CREATE TABLE `listings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `listings`
--

INSERT INTO `listings` (`id`, `user_id`, `title`, `logo`, `tags`, `company`, `location`, `email`, `website`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'Nihil est iste alias sunt ratione accusamus et dolorem.', NULL, 'laravel, api, backend', 'Effertz PLC', 'West Jensenside', 'vlangosh@beer.org', 'http://wunsch.com/sunt-harum-molestiae-est-libero-qui-molestiae-qui', 'Et accusantium nihil itaque aliquid nulla. Possimus numquam assumenda sunt. Unde suscipit culpa ea autem dolor. Exercitationem exercitationem sunt recusandae consequatur omnis assumenda aut sed.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(2, 1, 'Iusto dignissimos vel cumque voluptatum.', NULL, 'laravel, api, backend', 'Daugherty-Funk', 'North Albin', 'ellis.gerhold@roberts.info', 'http://homenick.org/', 'Nulla et hic cupiditate qui laboriosam voluptatem. Porro odio neque quis illum. Vitae error illo beatae et in tempora numquam. Repellendus ullam voluptas voluptatum id quia.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(3, 1, 'Ipsa reprehenderit est accusamus ut omnis occaecati consequatur.', NULL, 'laravel, api, backend', 'Homenick-Wilkinson', 'Velmabury', 'spencer.marquise@hills.net', 'http://www.hoeger.com/et-similique-veniam-corporis-nemo', 'Quo ipsum accusamus aut qui dolorem cum. Dolores fugiat reprehenderit quis eius. Commodi facilis exercitationem adipisci. Eum rem atque sapiente nam impedit soluta qui.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(4, 1, 'Ducimus optio suscipit non maxime ipsum at voluptas.', NULL, 'laravel, api, backend', 'Batz Group', 'Port Eugenia', 'nia52@stokes.com', 'http://gusikowski.net/voluptatum-quis-et-nihil-id', 'Cum ea est eligendi quas. Nostrum eius veniam deserunt ipsa ab facilis.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(5, 1, 'Ipsam sit laudantium enim eveniet sunt.', NULL, 'laravel, api, backend', 'Jacobs-Murray', 'Tillmanton', 'mmueller@hudson.com', 'http://www.hoeger.com/mollitia-rerum-optio-sunt-deleniti-alias-dignissimos', 'Inventore id ad in dolores sit voluptates quaerat. Qui doloribus nihil non. Commodi rem sequi velit.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(6, 1, 'Quo ad veritatis quis consequatur.', NULL, 'laravel, api, backend', 'Swaniawski Ltd', 'West Griffin', 'fritz.borer@zboncak.com', 'http://www.hessel.com/quo-consectetur-vero-perferendis-est-placeat.html', 'Voluptas ut fuga perspiciatis sunt. Consequatur quos molestiae autem voluptatem. Voluptatem accusantium quibusdam ut et rerum iste.', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(7, 2, 'Fryer', 'logos/aQ09vHNX9p1mHlsGHEeVNf1SZJQ0dnm1GXGaz87j.png', 'cook', 'McDonalds', 'Glencoe', 'mcdonalds@email.com', 'www.mcdonlads.com', 'Fry cook at McDonald\'s restaurant', '2022-05-21 12:39:52', '2022-05-21 13:47:58');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(21, '2014_10_12_000000_create_users_table', 1),
(22, '2014_10_12_100000_create_password_resets_table', 1),
(23, '2019_08_19_000000_create_failed_jobs_table', 1),
(24, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(25, '2022_05_17_180953_create_listings_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'billy', 'billy@email.com', '2022-05-21 12:17:36', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'uxcVECPXfH', '2022-05-21 12:17:36', '2022-05-21 12:17:36'),
(2, 'tim_password_timtimtim', 'tim@email.com', NULL, '$2y$10$BGa2lookaB/vcedL4N89CezZLgG2RUfIinTVt7/1qXZFm77BKJeUe', NULL, '2022-05-21 12:32:07', '2022-05-21 12:32:07'),
(3, 'jim_password_jimjimjim', 'jim@email.com', NULL, '$2y$10$L2pzAihEv3fgpbaVfSi7te8krUvC0byDpbKABzOITSmWQxOuf7R9.', NULL, '2022-05-21 13:56:12', '2022-05-21 13:56:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `listings_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `listings`
--
ALTER TABLE `listings`
  ADD CONSTRAINT `listings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
